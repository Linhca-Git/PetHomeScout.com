# Accessibility checklist

- [x] Semantic heading hierarchy and one H1 per representative route
- [x] Visible keyboard focus styles
- [x] Form labels and accessible error regions
- [x] Decorative icons hidden from assistive technology
- [x] Comparison tables use independent horizontal scroll regions
- [x] Mobile CTA targets are touch-sized
- [x] Footer contrast corrected for readable muted text
- [x] No page-wide horizontal overflow in local desktop/mobile QA

Final production audit remains required after real content and hosting are added.
